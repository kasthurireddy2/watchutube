# WatchUTube
### Search, Watch, Listen-- From the latest music videos to what’s popular in gaming, fashion, beauty, news, education and more. Check out channels you love and watch the videos on any device.
<hr>

## Screenshots🎞:
#### 1] Basic view :<br/>
<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190459199-a65f94c1-1a09-47c9-8ad1-86a8feee613d.png"><br/><br/>
#### 2] Watch Video :<br/>
<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190459614-d8eeafc1-a332-45ac-8152-811580ba981a.png"><br/><br/>
#### 3] Search Videos :<br/>
<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190460119-c73f0e34-228d-4a2d-abec-1128c05ebc14.png"><br/><br/>
#### 4] Visit Channels :<br/>
<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190461220-3916f60f-6fc4-4c70-9779-7f1775941cc2.png"><br/><br/>

<hr>

### Visit watchtube and have a Fun🌟!
https://watchutube.netlify.app/
